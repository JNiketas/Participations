﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionParticipation
{
    class Program
    {
        static void Main(string[] args)
        {
            List<double> gradelist = new List<double>();

            string answer;
            
                
              do
            {
                Console.WriteLine("Please enter your exam score. >>");
                string gradeasstring = Console.ReadLine();
                double grade = 0;

               gradelist.Add(grade);


                Console.WriteLine("Do you have another exam grade to enter? (Yes or No) >>");
                answer = Console.ReadLine();

            } while (answer.ToLower() == "yes");

            double maxgrade = gradelist[0];

            foreach (var grade in gradelist)
            {
                Console.WriteLine(gradelist[1]);
            }

            double mingrade = gradelist[0];

            foreach (var grade in gradelist)
            {
                mingrade = gradelist[0];
            }

            double sum = 0;

            foreach (var grade in gradelist)
            {
                sum = sum + grade;
            }

            double avg = sum / gradelist.Count;

            Console.WriteLine($"Your average exam grade is {avg}");
            Console.WriteLine($"Your minimum exam grade is {mingrade}");
            Console.WriteLine($"Your maximum exam grade is {maxgrade}");

            Console.ReadKey();
           

        }
    }
}
